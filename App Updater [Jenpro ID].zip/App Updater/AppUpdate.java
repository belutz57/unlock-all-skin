// By Jenpro ID

String versiku ="";
String up_data ="";
String up_versi ="";
String up_news ="";
final String nama_paket = "com.jenproid.multishortlink";
final Boolean isNewVersion;

// Simple Regex
String reg1 = "<span jsslot>";
String reg2 = "<div jsname=\"WgKync\"";
String reg3 = "htlgb\">";
String reg4 = "</span>";

try {
up_data = _data.substring(_data.lastIndexOf(reg1), _data.length());

// Get New Version
up_versi = up_data.substring(up_data.indexOf("Current Version"), up_data.indexOf("Requires"));
up_versi = up_versi.substring(up_versi.lastIndexOf(reg3) + 7, up_versi.indexOf(reg4));

// Get News Info
up_news = up_data.substring(up_data.indexOf(reg1), up_data.indexOf(reg2) - 7);
up_news = up_news.replace(reg1, "").replace("<br>", "\n");

android.content.pm.PackageInfo pinfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
versiku = pinfo.versionName;

} catch (Exception e) {
showMessage(e.toString()); 
versiku = "0";
}

isNewVersion = Float.parseFloat(versiku) >= Float.parseFloat(up_versi);