// By Jenpro ID

if (!isNewVersion) {
d.setTitle("New Version " + up_versi);
d.setCancelable(true);
d.setMessage(up_news);
d.setPositiveButton("Update", new DialogInterface.OnClickListener() {
	@Override public void onClick(DialogInterface _dialog, int _which) {
		startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + nama_paket)));
	}
});
d.setNegativeButton("Nanti", new DialogInterface.OnClickListener() {
	@Override public void onClick(DialogInterface _dialog, int _which) {
		finishAffinity();
	}
});
d.create().show();
}